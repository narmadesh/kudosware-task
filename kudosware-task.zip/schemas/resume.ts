export type Resume = {
  name: string;
  id: number;
};
