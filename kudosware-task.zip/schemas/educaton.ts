export type Education = {
  degree: string;
  university: string;
  score: string;
  yearOfCompletion: string;
  id?: number;
  userId: number;
};
